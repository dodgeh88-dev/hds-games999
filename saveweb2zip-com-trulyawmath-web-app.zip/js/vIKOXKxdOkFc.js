// === GLOBAL STATE ===
let gamesData = [];
let filteredGames = [];

// === DOM ELEMENTS ===
const gameSearch = document.getElementById('gameSearch');
const gamesGrid = document.getElementById('gamesGrid');
const vmContainer = document.getElementById('vmContainer');

// === GAMES ===
async function loadGames() {
  try {
    const res = await fetch('./json/games.json');
    const json = res.ok ? await res.json() : {};
    gamesData = json.games || [];
  } catch {
    gamesData = [];
  }
  filteredGames = [...gamesData];
  renderGames();
}

function renderGames() {
  if (!gamesGrid) return;
  if (!filteredGames.length) {
    gamesGrid.innerHTML = `<div class="loading"><i class="fas fa-search"></i><p>No games found</p></div>`;
    return;
  }
  gamesGrid.innerHTML = filteredGames.map(g => {
    const baseUrl = g.url ? g.url.replace(/\/[^/]*$/, '') : "";
    const faviconUrl = baseUrl ? `${baseUrl}/favicon.ico` : "";
    return `
      <div class="game-card" onclick="playGame('${g.url}','${g.title}')">
        <div class="game-image">
          <img class="game-favicon" src="${faviconUrl}" alt="icon"
               onerror="this.onerror=null;this.src='https://cdn-icons-png.flaticon.com/512/833/833472.png';">
        </div>
        <div class="game-info">
          <h3 class="game-title">${g.title}</h3>
          <p class="game-description">${g.description || ''}</p>
        </div>
      </div>`;
  }).join('');
}

function filterGames(term) {
  term = term.toLowerCase();
  filteredGames = gamesData.filter(g =>
    g.title?.toLowerCase().includes(term) ||
    (g.description || '').toLowerCase().includes(term)
  );
  renderGames();
}

// === VM ===
import Hyperbeam from "https://unpkg.com/@hyperbeam/web@latest/dist/index.js";

window.startVM = async function() {
  if (!vmContainer) return;
  vmContainer.innerHTML = `<div class="vm-placeholder"><p>Launching VM...</p></div>`;
  try {
    const res = await fetch("https://vmapi.ejgavin11.workers.dev");
    const data = await res.json();
    const vmUrl = data?.embed_url;
    if (vmUrl) {
      vmContainer.innerHTML = `<div id="virtualComputerDiv" style="height:600px;width:100%;border-radius:12px;overflow:hidden;"></div>`;
      const virtualComputerDiv = document.getElementById('virtualComputerDiv');
      await Hyperbeam(virtualComputerDiv, vmUrl);
      return;
    }
  } catch {}
  vmContainer.innerHTML = `<div class="vm-placeholder"><p>Failed to launch VM. This most likely means there are no VMs currently available.  This does NOT mean that VMs are broken.</p></div>`;
};

window.resetVM = function() {
  if (!vmContainer) return;
  vmContainer.innerHTML = `
    <div class="vm-placeholder">
      <div class="vm-icon"><i class="fas fa-desktop"></i></div>
      <h3>Virtual Machine Ready</h3>
      <p>Click "Start VM" to launch your virtual environment</p>
    </div>
  `;
};

window.fullscreenVM = function() {
  const vmDiv = document.getElementById('virtualComputerDiv');
  if (!vmDiv) return;
  if (vmDiv.requestFullscreen) {
    vmDiv.requestFullscreen();
  } else if (vmDiv.webkitRequestFullscreen) { // Safari
    vmDiv.webkitRequestFullscreen();
  } else if (vmDiv.msRequestFullscreen) { // IE11
    vmDiv.msRequestFullscreen();
  }
};

// === POPULAR URLS MODAL ===
window.showPopularUrls = async function() {
  try {
    const res = await fetch('json/popularurls.json');
    const data = await res.json();
    const list = document.getElementById('popularUrlsList');
    list.innerHTML = '';
    list.style.maxHeight = '400px';
    list.style.overflowY = 'auto';
    data.forEach(item => {
      const row = document.createElement('div');
      row.style.padding = '10px';
      row.style.background = '#2a2a3d';
      row.style.borderRadius = '8px';
      row.style.display = 'flex';
      row.style.justifyContent = 'space-between';
      row.style.alignItems = 'center';
      row.style.cursor = 'pointer';
      row.onmouseover = () => row.style.background = '#3b3b5c';
      row.onmouseout = () => row.style.background = '#2a2a3d';
      row.innerHTML = `<span>${item.name}</span><span style="color:#4fc3f7; text-decoration:underline;">Use this in your VM: ${item.url}</span>`;
      row.onclick = () => {
        navigator.clipboard.writeText(item.url).then(() => {
          alert('Copied to clipboard: ' + item.url);
        });
      };
      list.appendChild(row);
    });
    document.getElementById('popularUrlsModal').style.display = 'flex';
  } catch(err) {
    console.error(err);
    alert('Failed to load popular URLs.');
  }
};

window.closePopularUrls = function() {
  document.getElementById('popularUrlsModal').style.display = 'none';
};

// === INIT ===
document.addEventListener('DOMContentLoaded', () => {
  loadGames();
  if (gameSearch) gameSearch.addEventListener('input', e => filterGames(e.target.value));
});

// === WEBSOCKET CONNECTIVITY CHECK ===
window.wsTestPassed = false;

(function testWebSocket() {
  try {
    const ws = new WebSocket('wss://somestuffserver.koyeb.app/wsstest');
    ws.onopen = () => {
      ws.send('echo');
    };
    ws.onmessage = (event) => {
      if (event.data === 'echo') {
        window.wsTestPassed = true;
      }
      ws.close();
    };
    ws.onerror = () => {
      ws.close();
    };
  } catch(e) {
    // ignore errors
  }
})();

// === OVERRIDE showPage TO SHOW OVERLAY CONDITIONALLY ===
const originalShowPage = window.showPage;
window.showPage = function(pageId) {
  const overlay = document.getElementById('networkOverlay');
  if (overlay) {
    if ((pageId === 'prxy' || pageId === 'vm') && window.wsTestPassed === false) {
      overlay.classList.add('active');
    } else {
      overlay.classList.remove('active');
    }
  }
  if (typeof originalShowPage === 'function') {
    originalShowPage(pageId);
  }
};

// === DROPDOWN NAV ===
const moreDropdown = document.getElementById("moreDropdown");
const moreToggle = document.getElementById("moreToggle");
const moreLabel = document.getElementById("moreLabel");
const moreMenu = document.getElementById("moreMenu");

moreToggle.addEventListener("click", (e) => {
  e.preventDefault();
  moreDropdown.classList.toggle("open");
});

// Handle clicks inside dropdown and load page
moreMenu.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const pageId = link.dataset.page;
    if (pageId) {
      console.log("Dropdown nav clicked:", pageId);
      showPage(pageId);
      moreLabel.textContent = link.textContent.trim(); // Replace "More" with chosen label
    }
    moreDropdown.classList.remove("open");
  });
});

// Close dropdown if clicking outside
document.addEventListener("click", (e) => {
  if (!moreDropdown.contains(e.target)) {
    moreDropdown.classList.remove("open");
  }
});
